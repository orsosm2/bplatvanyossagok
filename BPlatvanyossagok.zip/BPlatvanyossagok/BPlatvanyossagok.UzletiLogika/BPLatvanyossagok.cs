﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPlatvanyossagok.UzletiLogika
{
    public class Latvanyossagok
    {
        public enum ErdekessegiSzint
        {
            Unalmas = 0,
            Átlagos = 1,
            EgészJó = 2,
            NagyonJó = 3
        }
    }
}
